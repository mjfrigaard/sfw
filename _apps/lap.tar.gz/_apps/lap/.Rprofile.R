if (interactive()) {
  require(usethis, quietly = TRUE)
}

options(shiny.testmode = TRUE)

