<h1 align="center"> <code>lap</code> </h1>
<h3 align="center"> A `leprechaun` app-package </h3>

<hr>

# lap

The goal of `lap` is to demonstrate the `leprechaun` framework.

## Download

You can download [here](https://github.com/mjfrigaard/sfw/raw/main/_apps/lap.tar.gz).

## Run

You can run the application with the following:

``` r
library(lap)
lap::run()
```
