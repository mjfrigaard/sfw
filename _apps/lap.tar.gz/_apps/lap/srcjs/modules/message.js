export const message = (msg) => {
  alert(msg);
}
