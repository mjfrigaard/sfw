`rhino` app pseudo-package
================

# `rap`

The goal of `rap` is to demonstrate the `rhino` framework.

## Run

You can run the application with the following:

``` r
rhino::app()
```
