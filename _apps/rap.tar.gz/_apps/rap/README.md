<h1 align="center"> <code>rap</code> </h1>
<h3 align="center"> A `rhino` pseudo-app package </h3>

<hr>

# rap

The goal of `rap` is to demonstrate the `rhino` framework.

## Download

You can download [here](https://github.com/mjfrigaard/sfw/raw/main/_apps/rap.tar.gz).

## Run

You can run the application with the following:

``` r
rhino::app()
```
