export function showHelp() {
  alert('Learn more about Rhino: https://appsilon.github.io/rhino/');
}
