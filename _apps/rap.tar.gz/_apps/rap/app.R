# Rhino / shinyApp entrypoint. Do not edit.
rhino::app()
