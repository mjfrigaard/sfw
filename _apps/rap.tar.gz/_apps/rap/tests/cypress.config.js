// tests/cypress/cypress.config.js
module.exports = {
  e2e: {
    setupNodeEvents(on, config) {},
    baseUrl: 'http://localhost:3333',
    supportFile: false,
  }
}