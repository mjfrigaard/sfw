// tests/cypress/e2e/message.cy.js

describe("Show message", () => {
  beforeEach(() => {
    cy.visit("/");
  });

  it("'Show message' button exists", () => {

  });

  it("'Show message' button shows the message'", () => {

  });
});