# gap (development version)

* Completed `dev/01_start.R`, `dev/02_dev.R`, and ``dev/03_deploy.R` scripts.

* Added a `NEWS.md` file to track changes to the package.
